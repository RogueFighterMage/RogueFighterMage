__________                          /\              
\______   \ ____   ____  __ __   ___)/              
 |       _//  _ \ / ___\|  |  \_/ __ \              
 |    |   (  <_> ) /_/  >  |  /\  ___/              
 |____|_  /\____/\___  /|____/  \___  >             
        \/      /_____/             \/              
     ___________.__       .__     __                
     \_   _____/|__| ____ |  |___/  |_  ___________ 
      |    __)  |  |/ ___\|  |  \   __\/ __ \_  __ \
      |     \   |  / /_/  >   Y  \  | \  ___/|  | \/
      \___  /   |__\___  /|___|  /__|  \___  >__|   
          \/      /_____/      \/          \/       
           _____      /\              /\            
          /     \ ____)/    ____   ___)/            
         /  \ /  \\__  \   / ___\_/ __ \            
        /    Y    \/ __ \_/ /_/  >  ___/            
        \____|__  (____  /\___  / \___  >           
                \/     \//_____/      \/   v1.1c


Rogue, Fighter, Mage: in the Goblin Caves

Copyright (c) 2017, mathpunk

All rights reserved.

The players' manual is online: http://forums.roguetemple.com/index.php?topic=5331.msg49249

Direct questions and comments to mathpunk@gmail.com

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
